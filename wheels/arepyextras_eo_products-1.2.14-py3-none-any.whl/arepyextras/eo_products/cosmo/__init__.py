# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
EO Products: COSMO SkyMed format manager
----------------------------------------
"""
