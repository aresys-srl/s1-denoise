# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
COSMO product format reader
---------------------------
"""

from __future__ import annotations

from pathlib import Path

import h5py
import numpy as np
from arepyextras.eo_products.common.utilities import SARProjection, SARRadiometricQuantity
from arepyextras.eo_products.cosmo.l1_products import utilities as support


def read_channel_metadata(file_path: str | Path, channel_id: str) -> support.COSMOChannelMetadata:
    """Reading channel metadata info and storing them in a COSMOChannelMetadata dataclass.

    Parameters
    ----------
    file_path : str | Path
        Path to the .h5 product
    channel_id : str
        selected channel id

    Returns
    -------
    support.COSMOChannelMetadata
        COSMOChannelMetadata metadata dataclass
    """

    root = h5py.File(file_path)
    root_attributes = root.attrs
    swath = root[channel_id.split("_")[0]]
    swath_attributes = swath.attrs
    raster = support.get_raster(root, channel_id)
    # Raster can have third axis if data is complex, in that case is real + imaginary
    lines, samples, *_ = raster.shape
    raster_attributes = raster.attrs

    # general info
    general_info = support.COSMOGeneralChannelInfo.from_metadata(
        root_attributes=root_attributes, swath_attributes=swath_attributes, channel_id=channel_id
    )

    # creating raster info
    raster_info = support.raster_info_from_metadata(
        root_attributes=root_attributes, raster_attributes=raster_attributes, lines=lines, samples=samples
    )

    # dataset info
    dataset_info = support.dataset_info_from_metadata(root_attributes=root_attributes)

    # state vectors
    state_vectors = support.COSMOStateVectors.from_metadata(root_attributes=root_attributes)
    orbit = support.orbit_from_state_vectors(state_vectors=state_vectors)

    # pulse info
    pulse_info = support.pulse_info_from_metadata(swath_attributes=swath_attributes)

    # sampling constants
    mid_range_incidence_angle_rad = np.deg2rad(
        (raster_attributes["Far Incidence Angle"] - raster_attributes["Near Incidence Angle"]) / 2
        + raster_attributes["Near Incidence Angle"]
    )
    sampling_constants = support.sampling_constants_from_metadata(
        swath_attributes=swath_attributes,
        raster_info=raster_info,
        mid_incidence_angle_rad=mid_range_incidence_angle_rad,
        product_type=general_info.product_level,
    )

    # calibration factor
    calibration_factor = support.compute_calibration_factor(
        root_attributes=root_attributes, calibration_constant=swath_attributes["Calibration Constant"]
    )

    # swath info
    swath_info = support.COSMOSwathInfo.from_metadata(swath_group=swath)

    # burst info
    burst_info = support.COSMOBurstInfo(
        num=1,
        lines_per_burst=raster_info.lines,
        samples_per_burst=raster_info.samples,
        azimuth_start_times=np.array([raster_info.lines_start]),
        range_start_times=np.array([raster_attributes["Zero Doppler Range First Time"]]),
    )

    # doppler polynomials
    doppler_rate_poly = support.doppler_rate_poly_from_metadata(root_attributes=root_attributes)
    doppler_centroid_poly = support.doppler_centroid_poly_from_metadata(root_attributes=root_attributes)

    # coordinate conversions
    if general_info.projection == SARProjection.GROUND_RANGE:
        range_step_m = (
            raster_info.samples_step
            if general_info.product_level == support.COSMOProductType.DGM
            else raster_info.samples_step / support.METERS_TO_SECONDS_CONVERSION
        )
        coordinate_conversions = support.COSMOCoordinateConversions.from_metadata(
            root_attributes=root_attributes, azimuth_ref=raster_info.lines_start, range_step_m=range_step_m
        )
    else:
        # TODO: add coordinate conversion section for slant range products
        coordinate_conversions = None

    root.close()

    return support.COSMOChannelMetadata(
        general_info=general_info,
        raster_info=raster_info,
        orbit=orbit,
        state_vectors=state_vectors,
        image_calibration_factor=calibration_factor,
        image_radiometric_quantity=SARRadiometricQuantity.SIGMA_NOUGHT,
        dataset_info=dataset_info,
        swath_info=swath_info,
        burst_info=burst_info,
        sampling_constants=sampling_constants,
        pulse=pulse_info,
        # acquisition_timeline=1,
        doppler_centroid_poly=doppler_centroid_poly,
        doppler_rate_poly=doppler_rate_poly,
        coordinate_conversions=coordinate_conversions,
    )


def read_channel_data(
    raster_file: str | Path,
    channel_id: str,
    block_to_read: list[int] | None = None,
    scaling_conversion: float = 1,
):
    """Reading ICEYE data file. It can be a GeoTiff .tif file (for GRD products) or an HDF5 .h5 file (for SLC).

    Parameters
    ----------
    raster_file : str | Path
        Path to GeoTiff .tif or HDF5 .h5 file
    block_to_read : list[int] | None, optional
        data block to be read, to be specified as a list of 4 integers, in the form:
            0. first line to be read
            1. first sample to be read
            2. total number of lines to be read
            3. total number of samples to be read

        by default None
    scaling_conversion : float, optional
        scaling conversion to be applied to the data read

    Returns
    -------
    np.ndarray
        numpy array containing the data read from raster file, with shape (lines, samples)
    """
    root = h5py.File(raster_file)
    raster = support.get_raster(root, channel_id)
    if block_to_read is not None:
        target_area = raster[
            block_to_read[0] : block_to_read[0] + block_to_read[2],
            block_to_read[1] : block_to_read[1] + block_to_read[3],
        ]
    else:
        target_area = raster[()]

    if len(target_area.shape) == 3:
        # With three dimension, last axis is real + imaginary
        target_area = target_area[:, :, 0] + 1j * target_area[:, :, 1]

    return target_area * scaling_conversion


def open_product(pf_path: str | Path) -> support.COSMOProduct:
    """Open a COSMO product.

    Parameters
    ----------
    pf_path : str | Path
        Path to the COSMO product

    Returns
    -------
    COSMOProduct
        COSMOProduct object corresponding to the input COSMO product
    """

    if not support.is_cosmo_product(product=pf_path):
        raise support.InvalidCOSMOProduct(f"{pf_path}")

    return support.COSMOProduct(path=pf_path)
