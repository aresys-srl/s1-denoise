# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
COSMO reader support module
---------------------------
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from pathlib import Path
from typing import Union

import arepytools.io.metadata as meta
import h5py
import numpy as np
import numpy.typing as npt
from arepyextras.eo_products.common.utilities import (
    ConversionPolynomial,
    OrbitDirection,
    SARPolarization,
    SARProjection,
    SARRadiometricQuantity,
    SARSamplingFrequencies,
    StandardSARAcquisitionMode,
)
from arepytools.constants import LIGHT_SPEED
from arepytools.geometry.orbit import Orbit
from arepytools.math.genericpoly import SortedPolyList, create_sorted_poly_list
from arepytools.timing.precisedatetime import PreciseDateTime
from numpy.polynomial import Polynomial
from numpy.typing import ArrayLike

_DATA_EXTENSION = ".h5"
METERS_TO_SECONDS_CONVERSION = 1 / (LIGHT_SPEED / 2)


class InvalidCOSMOProduct(RuntimeError):
    """Invalid COSMO product"""


class COSMOProductType(Enum):
    """COSMO Product Types"""

    DGM = "DGM"  # GRD
    SCS_B = "SCS_B"  # SLC product with range compensation applied
    SCS_U = "SCS_U"  # SLC product without range compensation applied


class COSMOAcquisitionModes(Enum):
    """COSMO supported acquisition modes"""

    SPOTLIGHT = auto()  # (Enhanced Spotlight)
    STRIPMAP = auto()  # (Himage, PingPong)
    SCANSAR = auto()  # (WideRegion, HugeRegion)


def raster_info_from_metadata(
    root_attributes: h5py.AttributeManager, raster_attributes: h5py.AttributeManager, lines: int, samples: int
) -> meta.RasterInfo:
    """Creating a RasterInfo Arepytools metadata object from metadata file.

    Parameters
    ----------
    root_attributes : h5py.AttributeManager
        metadata root attributes
    raster_attributes : h5py.AttributeManager
        metadata raster attributes
    lines : int
        number of azimuth lines
    samples : int
        number of range samples

    Returns
    -------
    meta.RasterInfo
        RasterInfo metadata object
    """

    product_type = detect_product_type(root_attributes["Product Type"].decode())
    # assuming SLC only
    file_name = root_attributes["Product Filename"].decode().strip(_DATA_EXTENSION)

    # lines
    lines_start = (
        PreciseDateTime.from_utc_string(root_attributes["Reference UTC"].decode())
        + raster_attributes["Zero Doppler Azimuth First Time"]
    )
    lines_step = raster_attributes["Line Time Interval"]
    lines_start_unit = "Utc"
    lines_step_unit = "s"

    # samples
    if product_type == COSMOProductType.DGM:
        samples_start = 0
        samples_step = raster_attributes["Column Spacing"]
        samples_start_unit = "m"
        samples_step_unit = "m"
        celltype = "FLOAT32"
    else:
        samples_start = raster_attributes["Zero Doppler Range First Time"]
        samples_step = raster_attributes["Column Time Interval"]
        samples_start_unit = "s"
        samples_step_unit = "s"
        celltype = "FLOAT_COMPLEX"

    # assembling RasterInfo
    raster_info = meta.RasterInfo(
        lines=lines,
        samples=samples,
        filename=file_name,
        celltype=celltype,
        header_offset_bytes=0,
        row_prefix_bytes=0,
        byteorder="LITTLEENDIAN",
    )
    raster_info.set_lines_axis(
        lines_start=lines_start,
        lines_start_unit=lines_start_unit,
        lines_step=lines_step,
        lines_step_unit=lines_step_unit,
    )
    raster_info.set_samples_axis(
        samples_start=samples_start,
        samples_start_unit=samples_start_unit,
        samples_step=samples_step,
        samples_step_unit=samples_step_unit,
    )

    return raster_info


def dataset_info_from_metadata(root_attributes: h5py.AttributeManager) -> meta.DataSetInfo:
    """Creating a DataSetInfo Arepytools metadata object from metadata file.

    Parameters
    ----------
    root_attributes : h5py.AttributeManager
        metadata root attributes

    Returns
    -------
    DataSetInfo
        DataSetInfo metadata object
    """
    prod_type = detect_product_type(root_attributes["Product Type"].decode())

    dataset_info = meta.DataSetInfo(
        acquisition_mode_i=detect_acquisition_mode(root_attributes["Acquisition Mode"].decode()).name,
        fc_hz_i=root_attributes["Radar Frequency"],
    )
    dataset_info.sensor_name = root_attributes["Satellite ID"].decode()
    match prod_type:
        case COSMOProductType.DGM:
            dataset_info.image_type = "MULTILOOK"
        case COSMOProductType.SCS_B:
            dataset_info.image_type = "AZIMUTH FOCUSED RANGE COMPENSATED"
        case COSMOProductType.SCS_U:
            dataset_info.image_type = "AZIMUTH FOCUSED"

    dataset_info.projection = "GROUND RANGE" if prod_type == COSMOProductType.DGM else "SLANT RANGE"
    dataset_info.side_looking = root_attributes["Look Side"].decode()

    return dataset_info


# TODO: implement acquisition timeline
# def acquisition_timeline_from_metadata(root: etree._Element | h5py.File) -> meta.AcquisitionTimeLine:
#     """Creating a AcquisitionTimeLine Arepytools metadata object from metadata file.

#     Parameters
#     ----------
#     root : etree._Element | h5py.File
#         metadata root object

#     Returns
#     -------
#     AcquisitionTimeLine
#         AcquisitionTimeLine metadata object
#     """
#     if isinstance(root, h5py.File):
#         swst_changes_val = root["slant_range_to_first_pixel"][()] / (LIGHT_SPEED / 2)
#         swl_changes_val = root["number_of_range_samples"][()] / root["range_sampling_rate"][()]
#     else:
#         swst_changes_val = float(root.find("slant_range_to_first_pixel").text) / (LIGHT_SPEED / 2)
#         swl_changes_val = float(root.find("number_of_range_samples").text) / float(
#             root.find("range_sampling_rate").text
#         )

#     return meta.AcquisitionTimeLine(
#         swst_changes_number_i=1,
#         swst_changes_azimuth_times_i=[0],
#         swst_changes_values_i=[swst_changes_val],
#         swl_changes_number_i=1,
#         swl_changes_azimuth_times_i=[0],
#         swl_changes_values_i=[swl_changes_val],
#     )


def doppler_centroid_poly_from_metadata(root_attributes: h5py.AttributeManager) -> SortedPolyList:
    """Creating a SortedPolyList Arepytools doppler centroid polynomial wrapper from metadata.

    Parameters
    ----------
    root_attributes : h5py.AttributeManager
        metadata root attributes

    Returns
    -------
    SortedPolyList
        SortedPolyList wrapper on DopplerCentroidVector metadata object
    """
    # TODO: use also the azimuth polynomial?
    doppler_rate_poly = root_attributes["Centroid vs Range Time Polynomial"]
    ref_az_time = root_attributes["Azimuth Polynomial Reference Time"] + PreciseDateTime.from_utc_string(
        root_attributes["Reference UTC"].decode()
    )
    ref_rng_time = root_attributes["Range Polynomial Reference Time"]

    doppler_poly = [
        meta.DopplerCentroid(
            i_ref_az=ref_az_time,
            i_ref_rg=ref_rng_time,
            i_coefficients=[
                doppler_rate_poly[0],
                doppler_rate_poly[1],
                0,
                0,
                doppler_rate_poly[2],
                doppler_rate_poly[3],
                doppler_rate_poly[4],
                doppler_rate_poly[5],
                0,
                0,
                0,
            ],
        )
    ]

    return create_sorted_poly_list(meta.DopplerCentroidVector(i_poly2d=doppler_poly))


def doppler_rate_poly_from_metadata(root_attributes: h5py.AttributeManager) -> SortedPolyList:
    """Creating a SortedPolyList Arepytools doppler rate vector polynomial wrapper from metadata.

    Parameters
    ----------
    root_attributes : h5py.AttributeManager
        metadata root attributes

    Returns
    -------
    SortedPolyList
        SortedPolyList wrapper on DopplerRateVector metadata object
    """
    # TODO: use also the azimuth polynomial?
    doppler_rate_poly = root_attributes["Doppler Rate vs Range Time Polynomial"]
    ref_az_time = root_attributes["Azimuth Polynomial Reference Time"] + PreciseDateTime.from_utc_string(
        root_attributes["Reference UTC"].decode()
    )
    ref_rng_time = root_attributes["Range Polynomial Reference Time"]

    doppler_rate_poly = [
        meta.DopplerRate(
            i_ref_az=ref_az_time,
            i_ref_rg=ref_rng_time,
            i_coefficients=[
                doppler_rate_poly[0],
                doppler_rate_poly[1],
                0,
                0,
                doppler_rate_poly[2],
                doppler_rate_poly[3],
                doppler_rate_poly[4],
                doppler_rate_poly[5],
                0,
                0,
                0,
            ],
        )
    ]

    return create_sorted_poly_list(meta.DopplerRateVector(i_poly2d=doppler_rate_poly))


def sampling_constants_from_metadata(
    swath_attributes: h5py.AttributeManager,
    raster_info: meta.RasterInfo,
    mid_incidence_angle_rad: float,
    product_type: COSMOProductType,
) -> SARSamplingFrequencies:
    """Creating a SARSamplingFrequencies metadata object from metadata file.

    Parameters
    ----------
    swath_attributes : h5py.AttributeManager
        metadata swath attributes
    raster_info : meta.RasterInfo
        raster info
    mid_incidence_angle_rad : float
        incidence angle rad at mid swath
    product_type : COSMOProductType
        product type

    Returns
    -------
    SARSamplingFrequencies
        SARSamplingFrequencies metadata object
    """

    range_freq_hz = 1 / raster_info.samples_step
    range_bandwidth_freq_hz = swath_attributes["Range Focusing Bandwidth"]

    azimuth_freq_hz = 1 / raster_info.lines_step
    azimuth_bandwidth_freq_hz = swath_attributes["Azimuth Focusing Transition Bandwidth"]

    return SARSamplingFrequencies(
        azimuth_freq_hz=azimuth_freq_hz,
        azimuth_bandwidth_freq_hz=azimuth_bandwidth_freq_hz,
        range_freq_hz=range_freq_hz,
        range_bandwidth_freq_hz=range_bandwidth_freq_hz,
    )


def pulse_info_from_metadata(swath_attributes: h5py.AttributeManager) -> meta.Pulse:
    """Creating a Pulse Arepytools metadata object from metadata.

    Parameters
    ----------
    swath_attributes : h5py.AttributeManager
        metadata swath attributes

    Returns
    -------
    meta.Pulse
        Pulse metadata object
    """

    # TODO: bandwidth? pulse direction?
    chirp_bandwidth = 0
    return meta.Pulse(
        i_pulse_length=swath_attributes["Range Chirp Length"],
        i_bandwidth=chirp_bandwidth,
        i_pulse_sampling_rate=swath_attributes["Sampling Rate"],
        i_pulse_energy=1,
        i_pulse_start_frequency=-chirp_bandwidth / 2,
        i_pulse_start_phase=0,
        i_pulse_direction=meta.EPulseDirection.up.value,
    )


def orbit_from_state_vectors(state_vectors: COSMOStateVectors) -> Orbit:
    """Creating an Orbit Arepytools object from COSMOStateVectors data.

    Parameters
    ----------
    state_vectors : COSMOStateVectors
        state vectors data

    Returns
    -------
    Orbit
        Orbit object
    """
    return Orbit(times=state_vectors.time_axis, positions=state_vectors.positions, velocities=state_vectors.velocities)


def compute_calibration_factor(root_attributes: h5py.AttributeManager, calibration_constant: float) -> float:
    """Computing calibration factor to be applied to the image raster to get Sigma Nought radiometric quantity.

    Parameters
    ----------
    root_attributes : h5py.AttributeManager
        metadata root attributes
    calibration_constant : float
        calibration constant

    Returns
    -------
    float
        calibration factor
    """
    factor = 1 / (root_attributes["Rescaling Factor"] ** 2)
    if root_attributes["Range Spreading Loss Compensation Geometry"].decode() != "NONE":
        factor *= root_attributes["Reference Slant Range"] ** (2 * root_attributes["Reference Slant Range Exponent"])
    if root_attributes["Incidence Angle Compensation Geometry"].decode() != "NONE":
        factor *= np.sin(np.deg2rad(root_attributes["Reference Incidence Angle"]))
    if root_attributes["Calibration Constant Compensation Flag"] == 0:
        factor *= 1 / calibration_constant

    return np.sqrt(factor)


def detect_acquisition_mode(acq_mode_str: str) -> COSMOAcquisitionModes:
    """Detect Acquisition Mode from string.

    Parameters
    ----------
    acq_mode_str : str
        annotated acquisition mode

    Returns
    -------
    COSMOAcquisitionModes
        COSMO Acquisition Mode enum
    """
    if "region" in acq_mode_str.lower():  # Expected HUGEREGION or WIDEREGION
        return COSMOAcquisitionModes.SCANSAR

    if "spotlight" in acq_mode_str.lower():
        return COSMOAcquisitionModes.SPOTLIGHT

    return COSMOAcquisitionModes.STRIPMAP


def detect_product_type(product_type_str: str) -> COSMOProductType:
    """Detect Product Type from string.

    Parameters
    ----------
    product_type_str : str
        annotated product type

    Returns
    -------
    COSMOProductType
        COSMO Product Type enum
    """

    if "DGM" in product_type_str:
        return COSMOProductType.DGM

    if "SCS_B" in product_type_str:
        return COSMOProductType.SCS_B

    return COSMOProductType.SCS_U


def _get_channels_names(root: h5py.File) -> list[str]:
    """Combining swath names and polarizations to get the channel ids.

    Parameters
    ----------
    root : h5py.File
        root object

    Returns
    -------
    list[str]
        list of channel ids as "swath_polarization"
    """
    swaths = [s for s in root.keys() if "S0" in s]
    polarizations = [root[s].attrs["Polarisation"].decode() for s in swaths]

    return ["_".join([s, p]) for s, p in list(zip(swaths, polarizations))]


def _get_footprint(rasters: list[h5py.Dataset]) -> list[float, float, float, float]:
    """Get scene footprint from corner coordinates.

    Parameters
    ----------
    raster : h5py.Dataset
        raster dataset

    Returns
    -------
    list[float, float, float, float]
        min latitude, max latitude, min longitude, max longitude
    """
    footprint = np.stack(
        [
            [
                raster.attrs["Bottom Left Geodetic Coordinates"][:-1],
                raster.attrs["Bottom Right Geodetic Coordinates"][:-1],
                raster.attrs["Top Left Geodetic Coordinates"][:-1],
                raster.attrs["Top Right Geodetic Coordinates"][:-1],
            ]
            for raster in rasters
        ]
    )
    min_lat, min_lon = np.min(np.min(footprint, axis=1), axis=0)
    max_lat, max_lon = np.max(np.max(footprint, axis=1), axis=0)

    return [min_lat, max_lat, min_lon, max_lon]


def get_raster(root: h5py.File, channel_id: str) -> h5py.Dataset:
    """Get the raster associated to a channel.

    Parameters
    ----------
    root : h5py.File
        root object
    channel_id : str
        selected channel id

    Returns
    -------
    h5py.Dataset
        Raster dataset
    """
    # Recover raster. If product is geocoded or geodetected and it's a ScanSAR, there's the single MBI raster, otherwise
    # pick the SBI associated to swath
    product_type = detect_product_type(root.attrs["Product Type"].decode())
    acquisition_mode = detect_acquisition_mode(root.attrs["Acquisition Mode"].decode())

    if product_type == COSMOProductType.DGM and acquisition_mode == COSMOAcquisitionModes.SCANSAR:
        return root["MBI"]

    return root[channel_id.split("_")[0]]["SBI"]


@dataclass
class COSMOBurstInfo:
    """COSMO swath burst info"""

    num: int  # number of bursts in this swath
    lines_per_burst: int  # number of azimuth lines within each burst
    samples_per_burst: int  # number of range samples within each burst
    azimuth_start_times: np.ndarray  # zero doppler azimuth time of the first line of this burst
    range_start_times: np.ndarray  # zero doppler range time of the first sample of this burst

    # TODO: this should be class method?
    @staticmethod
    def from_metadata(swath_group: h5py.Group, samples_per_burst: int, ref_time: PreciseDateTime) -> COSMOBurstInfo:
        """Generating COSMOBurstInfo object directly from metadata.

        Parameters
        ----------
        swath_group : h5py.Group
            metadata swath group
        samples_per_burst : int
            samples per burst
        ref_time : PreciseDateTime
            reference UTC time

        Returns
        -------
        COSMOBurstInfo
            burst info dataclass
        """
        bursts = [key for key in swath_group.keys() if re.match(r"^B\d{3}$", key)]
        azimuth_start_times = np.array([swath_group[b].attrs["Azimuth First Time"] for b in bursts]) + ref_time
        range_start_times = np.array([swath_group[b].attrs["Range First Times"][0] for b in bursts])
        return COSMOBurstInfo(
            num=len(bursts),
            lines_per_burst=int(swath_group.attrs["Lines per Burst"]),
            samples_per_burst=samples_per_burst,
            azimuth_start_times=azimuth_start_times,
            range_start_times=range_start_times,
        )


@dataclass
class COSMOSwathInfo:
    """COSMO swath info"""

    rank: int
    azimuth_steering_rate_poly: tuple[float, float, float]
    prf: float

    # TODO: this should be class method?
    @staticmethod
    def from_metadata(swath_group: h5py.Group) -> COSMOSwathInfo:
        """Generating COSMOSwathInfo object directly from metadata.

        Parameters
        ----------
        swath_group : h5py.Group
            metadata swath group


        Returns
        -------
        COSMOSwathInfo
            swath info dataclass
        """
        rank = swath_group.attrs["Rank"]
        acquisition_prf = swath_group.attrs["PRF"]

        # Pick steering  from first burst
        azimuth_steering_deg = swath_group["B001"].attrs["Azimuth Steering"]
        line_changes = swath_group["B001"].attrs["Azimuth Ramp Code Change Lines"]

        if len(azimuth_steering_deg) > 1:
            steering_rate_rad_sec = np.deg2rad(
                (azimuth_steering_deg[-1] - azimuth_steering_deg[0])
                / (line_changes[-1] - line_changes[0])
                * acquisition_prf
            )
            azimuth_steering_rate_poly = (steering_rate_rad_sec, 0, 0)
        else:
            azimuth_steering_rate_poly = (0, 0, 0)

        return COSMOSwathInfo(
            rank=rank,
            azimuth_steering_rate_poly=azimuth_steering_rate_poly,
            prf=acquisition_prf,
        )


@dataclass
class COSMOStateVectors:
    """COSMO orbit's state vectors"""

    num: int  # attitude data numerosity
    positions: np.ndarray  # platform position data with respect to the Earth-fixed reference frame
    velocities: np.ndarray  # platform velocity data with respect to the Earth-fixed reference frame
    time_axis: np.ndarray  # PreciseDateTime axis at which orbit state vectors apply
    time_step: float  # time axis step
    orbit_direction: OrbitDirection  # orbit direction: ascending or descending

    @staticmethod
    def from_metadata(root_attributes: h5py.AttributeManager) -> COSMOStateVectors:
        """Generating a COSMOStateVectors object directly from metadata file.

        Parameters
        ----------
        root_attributes : h5py.AttributeManager
            metadata root attributes

        Returns
        -------
        COSMOStateVectors
            orbit's state vectors dataclass
        """

        numerosity = root_attributes["Number of State Vectors"]
        positions = root_attributes["ECEF Satellite Position"]
        velocities = root_attributes["ECEF Satellite Velocity"]
        time_axis = root_attributes["State Vectors Times"] + PreciseDateTime.from_utc_string(
            root_attributes["Reference UTC"].decode()
        )

        assert positions.shape[0] == velocities.shape[0] == time_axis.size == numerosity

        return COSMOStateVectors(
            num=numerosity,
            positions=positions,
            velocities=velocities,
            time_axis=time_axis,
            time_step=time_axis[1] - time_axis[0],
            orbit_direction=OrbitDirection[root_attributes["Orbit Direction"].decode()],
        )


@dataclass
class COSMOCoordinateConversions:
    """COSMO coordinate conversion"""

    ground_to_slant: list[ConversionPolynomial] | None = None
    slant_to_ground: list[ConversionPolynomial] | None = None
    azimuth_reference_times: np.ndarray | None = None

    def _detect_right_polynomial_index(self, azimuth_time: PreciseDateTime) -> int:
        """Detecting the index of the right polynomial to be used given an input azimuth time.
        The polynomial to be used is the one with reference azimuth time closest to the input value but with
        reference_azimuth_time < input_azimuth_time.

        Parameters
        ----------
        azimuth_time : PreciseDateTime
            selected azimuth time

        Returns
        -------
        int
            index corresponding to the polynomial to be used
        """
        diff = np.array(azimuth_time - self.azimuth_reference_times).astype("float")
        return np.ma.masked_where(diff < 0, diff).argmin()

    @staticmethod
    def from_metadata(
        root_attributes: h5py.AttributeManager, azimuth_ref: PreciseDateTime, range_step_m: float
    ) -> COSMOCoordinateConversions:
        """Generating COSMOCoordinateConversions object directly from metadata.

        Parameters
        ----------
        root_attributes : h5py.AttributeManager
            metadata root attributes
        azimuth_ref_time : PreciseDateTime
            reference azimuth time

        Returns
        -------
        COSMOCoordinateConversions
            polynomial for coordinate conversion dataclass
        """

        origin = root_attributes["Ground Projection Polynomial Reference Range"]
        slant_origin = origin * METERS_TO_SECONDS_CONVERSION
        # TODO: must divide by samples step in meters
        # check with current translated product and its usage in quality protocol for PF
        slant_to_ground_coefficients = [
            c / (METERS_TO_SECONDS_CONVERSION**c_id) * range_step_m
            for c_id, c in enumerate(root_attributes["Slant to Ground Polynomial"])
        ]
        ground_to_slant_coefficients = [
            c / (range_step_m**c_id) * METERS_TO_SECONDS_CONVERSION
            for c_id, c in enumerate(root_attributes["Ground to Slant Polynomial"])
        ]
        ground_to_slant_coefficients[0] += slant_origin

        ground_to_slant_poly = Polynomial(ground_to_slant_coefficients)
        slant_to_ground_poly = Polynomial(slant_to_ground_coefficients)

        # assembling list of polynomials
        ground_to_slant_poly_list = [
            ConversionPolynomial(
                azimuth_reference_time=azimuth_ref,
                origin=0,
                polynomial=ground_to_slant_poly,
            )
        ]
        slant_to_ground_poly_list = [
            ConversionPolynomial(
                azimuth_reference_time=azimuth_ref,
                origin=slant_origin,
                polynomial=slant_to_ground_poly,
            )
        ]

        return COSMOCoordinateConversions(
            azimuth_reference_times=np.array([azimuth_ref]),
            ground_to_slant=ground_to_slant_poly_list,
            slant_to_ground=slant_to_ground_poly_list,
        )

    def evaluate_ground_to_slant(self, azimuth_time: PreciseDateTime, ground_range: ArrayLike) -> float:
        """Compute ground to slant conversion.

        Parameters
        ----------
        azimuth_time : PreciseDateTime
            azimuth time to select the proper polynomial to be used for conversion
        ground_range :  ArrayLike
            ground range values in meters

        Returns
        -------
        float
            slant range value
        """
        poly_index = self._detect_right_polynomial_index(azimuth_time=azimuth_time)
        poly = self.ground_to_slant[poly_index]
        return poly.polynomial(ground_range - poly.origin)

    def evaluate_slant_to_ground(
        self, azimuth_time: PreciseDateTime, slant_range: Union[float, npt.ArrayLike]
    ) -> float:
        """Compute slant to ground conversion.

        Parameters
        ----------
        azimuth_time : PreciseDateTime
            azimuth time to select the proper polynomial to be used for conversion
        slant_range :  Union[float, npt.ArrayLike]
            slant range value(s) in meters

        Returns
        -------
        float
            ground range value
        """
        poly_index = self._detect_right_polynomial_index(azimuth_time=azimuth_time)
        poly = self.slant_to_ground[poly_index]
        return poly.polynomial(slant_range - poly.origin)


@dataclass
class COSMOGeneralChannelInfo:
    """COSMO general channel info dataclass"""

    product_name: str
    channel_id: str
    swath: str
    product_level: COSMOProductType
    polarization: SARPolarization
    projection: SARProjection
    acquisition_mode: COSMOAcquisitionModes
    acquisition_mode_std: StandardSARAcquisitionMode
    orbit_direction: OrbitDirection
    signal_frequency: float
    acq_start_time: PreciseDateTime
    acq_stop_time: PreciseDateTime

    @staticmethod
    def from_metadata(
        root_attributes: h5py.AttributeManager, swath_attributes: h5py.AttributeManager, channel_id: str
    ) -> COSMOGeneralChannelInfo:
        """Generating COSMOGeneralChannelInfo object directly from metadata.

        Parameters
        ----------
        root_attributes : h5py.AttributeManager
            metadata root attributes
        swath_attributes : h5py.AttributeManager
            metadata swath attributes
        channel_id : str
            channel id

        Returns
        -------
        COSMOGeneralChannelInfo
            general channel info dataclass
        """
        product_level = detect_product_type(root_attributes["Product Type"].decode())
        acq_mode = detect_acquisition_mode(root_attributes["Acquisition Mode"].decode())
        if acq_mode == COSMOAcquisitionModes.SCANSAR:
            acq_mode_std = StandardSARAcquisitionMode.SCANSAR
        elif acq_mode == COSMOAcquisitionModes.STRIPMAP:
            acq_mode_std = StandardSARAcquisitionMode.STRIPMAP
        else:
            acq_mode_std = StandardSARAcquisitionMode.SPOTLIGHT
        return COSMOGeneralChannelInfo(
            product_name=root_attributes["Product Filename"].decode().strip(_DATA_EXTENSION),
            channel_id=channel_id,
            swath=channel_id.split("_")[0],
            product_level=product_level,
            polarization=SARPolarization[swath_attributes["Polarisation"].decode()],
            projection=(
                SARProjection.GROUND_RANGE if product_level == COSMOProductType.DGM else SARProjection.SLANT_RANGE
            ),
            acquisition_mode=acq_mode,
            acquisition_mode_std=acq_mode_std,
            orbit_direction=OrbitDirection[root_attributes["Orbit Direction"].decode()],
            signal_frequency=root_attributes["Radar Frequency"],
            acq_start_time=PreciseDateTime.from_utc_string(root_attributes["Scene Sensing Start UTC"].decode()),
            acq_stop_time=PreciseDateTime.from_utc_string(root_attributes["Scene Sensing Stop UTC"].decode()),
        )


@dataclass
class COSMOChannelMetadata:
    """COSMO channel metadata dataclass"""

    general_info: COSMOGeneralChannelInfo
    orbit: Orbit
    image_calibration_factor: float
    image_radiometric_quantity: SARRadiometricQuantity
    burst_info: COSMOBurstInfo
    raster_info: meta.RasterInfo
    dataset_info: meta.DataSetInfo
    swath_info: COSMOSwathInfo
    sampling_constants: SARSamplingFrequencies
    # acquisition_timeline: meta.AcquisitionTimeLine
    doppler_centroid_poly: SortedPolyList
    doppler_rate_poly: SortedPolyList
    pulse: meta.Pulse
    coordinate_conversions: COSMOCoordinateConversions | None
    state_vectors: COSMOStateVectors


class COSMOProduct:
    """COSMO product object"""

    def __init__(self, path: str | Path) -> None:
        """COSMO Product init from directory path.

        Parameters
        ----------
        path : str | Path
            path to COSMO product
        """
        self._product_path = Path(path)
        self._product_name = self._product_path.name
        root = h5py.File(path)
        product_type = detect_product_type(root.attrs["Product Type"].decode())
        self._acq_time = PreciseDateTime.from_utc_string(root.attrs["Scene Sensing Start UTC"].decode())
        channels_list = _get_channels_names(root)
        if product_type == COSMOProductType.DGM:
            # swaths and burst are already merged, so taking only the first swath as reference because
            # swath attributes are not used in this case
            channels_list = [channels_list[0]]
        self._channels_list = channels_list
        self._channels_number = len(self._channels_list)
        # Get all the rasters to compute footprint
        rasters = [get_raster(root, channel_id) for channel_id in channels_list]
        self._footprint = _get_footprint(rasters)
        root.close()

    @property
    def acquisition_time(self) -> PreciseDateTime:
        """Acquisition start time for this product"""
        return self._acq_time

    @property
    def channels_number(self) -> int:
        """Returning the number of channels of COSMO product"""
        return self._channels_number

    @property
    def channels_list(self) -> list[str]:
        """Returning the list of channels"""
        return self._channels_list

    @property
    def footprint(self) -> tuple[float, float, float, float]:
        """Product footprint as tuple of (min lat, max lat, min lon, max lon)"""
        return self._footprint


def is_cosmo_product(product: str | Path) -> bool:
    """Check if input path corresponds to a valid COSMO product, basic version.

    Conditions to be met for basic validity:
        - path exists
        - path is a .h5 file
        - open file and read acquisition mode

    Parameters
    ----------
    product : str | Path
        path to the product to be checked

    Returns
    -------
    bool
        True if it is a valid product, else False
    """
    product = Path(product)

    if not product.exists():
        return False

    if not str(product).endswith(_DATA_EXTENSION):
        return False

    # open product, read acquisition mode
    try:
        root = h5py.File(product)
        detect_product_type(root.attrs["Product Type"].decode())
    except Exception:
        return False
    finally:
        root.close()

    return True
