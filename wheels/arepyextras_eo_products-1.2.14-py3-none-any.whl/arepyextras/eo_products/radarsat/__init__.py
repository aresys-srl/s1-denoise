# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
EO Products: RADARSAT-2 format manager
--------------------------------------
"""
