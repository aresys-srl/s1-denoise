# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
RADARSAT-2 reader support module
--------------------------------
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from pathlib import Path

import arepytools.io.metadata as meta
import numpy as np
from arepyextras.eo_products.common.utilities import (
    ConversionPolynomial,
    OrbitDirection,
    SARPolarization,
    SARProjection,
    SARRadiometricQuantity,
    SARSamplingFrequencies,
    StandardSARAcquisitionMode,
)
from arepytools.constants import LIGHT_SPEED
from arepytools.geometry.orbit import Orbit
from arepytools.math.genericpoly import SortedPolyList, create_sorted_poly_list
from arepytools.timing.precisedatetime import PreciseDateTime
from lxml import etree
from numpy.polynomial import Polynomial
from numpy.typing import ArrayLike

_METADATA_FILE = "product.xml"
_IMAGE_FORMAT = ".tif"
_DATA_SUFFIX = "imagery"
_LUT_BETA_FILE = "lutBeta.xml"


class RADARSATTimeOrdering(Enum):
    """RADARSAT-2 available Time Ordering"""

    INCREASING = "Increasing"
    DECREASING = "Decreasing"


class RADARSATProductType(Enum):
    """RADARSAT-2 L1 product types"""

    SLC = "SLC"  # stripmap, single look, complex, slant range
    SGF = "SGF"  # SAR Georeferenced Fine product
    SGX = "SGX"  # SAR Georeferenced Extra-Fine product
    SGC = "SGC"  # SAR Georeferenced Coarse product
    SSG = "SSG"  # SAR Systematic Geocorrected product
    SPG = "SPG"  # SAR Precision Geocorrected product
    SCF = "SCF"  # ScanSAR Sampled product type
    SCS = "SCS"  # ScanSAR Sampled product type


class RADARSATAcquisitionModes(Enum):
    """RADARSAT-2 L1 acquisition modes"""

    STRIPMAP = auto()
    SCANSAR = auto()
    SPOTLIGHT = auto()


class InvalidRADARSATProduct(RuntimeError):
    """Invalid RADARSAT-2 product"""


def read_lut(path: str | Path) -> float:
    """Reading Beta LUT calibration file to extract the calibration factor.

    Parameters
    ----------
    path : str | Path
        Path to the Beta LUT calibration .xml file

    Returns
    -------
    float
        calibration factor
    """
    root = etree.parse(str(path)).getroot()
    gain = root.find("gains")
    calibration_factor = {float(f) for f in gain.text.split()}
    assert len(calibration_factor) == 1
    return calibration_factor.pop()


def raster_info_from_metadata(
    image_generation_parameters_node: etree._Element,
    image_attributes_node: etree._Element,
    namespace: dict[str, str],
    projection: SARProjection,
) -> meta.RasterInfo:
    """Creating a RasterInfo Arepytools metadata element from xml node.

    Parameters
    ----------
    image_generation_parameters_node : etree._Element
        imageGenerationParameters metadata xml node
    image_attributes_node : etree._Element
        imageAttributes metadata xml node
    namespace : dict[str, str]
        xml namespace
    projection : SARProjection
        SAR data projection

    Returns
    -------
    RasterInfo
        RasterInfo metadata object
    """
    lines = int(
        image_attributes_node.xpath(".//base:rasterAttributes/base:numberOfLines", namespaces=namespace)[0].text
    )
    samples = int(
        image_attributes_node.xpath(".//base:rasterAttributes/base:numberOfSamplesPerLine", namespaces=namespace)[
            0
        ].text
    )
    first_doppler_time = PreciseDateTime.fromisoformat(
        image_generation_parameters_node.xpath(
            ".//base:sarProcessingInformation/base:zeroDopplerTimeFirstLine", namespaces=namespace
        )[0].text
    )
    last_doppler_time = PreciseDateTime.fromisoformat(
        image_generation_parameters_node.xpath(
            ".//base:sarProcessingInformation/base:zeroDopplerTimeLastLine", namespaces=namespace
        )[0].text
    )
    if last_doppler_time < first_doppler_time:
        lines_start = last_doppler_time
    else:
        lines_start = first_doppler_time
    lines_step = abs(first_doppler_time - last_doppler_time) / (lines - 1)
    lines_start_unit = "Utc"
    lines_step_unit = "s"

    # samples
    if projection == SARProjection.SLANT_RANGE:
        # slant range
        samples_start = float(
            image_generation_parameters_node.xpath(
                ".//base:sarProcessingInformation/base:slantRangeNearEdge", namespaces=namespace
            )[0].text
        ) / (LIGHT_SPEED / 2)
        samples_start_unit = "s"
        samples_step = float(
            image_attributes_node.xpath(".//base:sampledPixelSpacing", namespaces=namespace)[0].text
        ) / (LIGHT_SPEED / 2)
        samples_step_unit = "s"
        celltype = "FLOAT_COMPLEX"
    else:
        # ground range
        samples_start = 0
        samples_start_unit = "m"
        samples_step = float(image_attributes_node.xpath(".//base:sampledPixelSpacing", namespaces=namespace)[0].text)
        samples_step_unit = "m"
        celltype = "FLOAT32"

    raster_info = meta.RasterInfo(
        lines=lines,
        samples=samples,
        celltype=celltype,
        filename=None,
        header_offset_bytes=0,
        row_prefix_bytes=0,
        byteorder="LITTLEENDIAN",
    )
    raster_info.set_lines_axis(
        lines_start=lines_start,
        lines_start_unit=lines_start_unit,
        lines_step=lines_step,
        lines_step_unit=lines_step_unit,
    )
    raster_info.set_samples_axis(
        samples_start=samples_start,
        samples_start_unit=samples_start_unit,
        samples_step=samples_step,
        samples_step_unit=samples_step_unit,
    )

    return raster_info


def dataset_info_from_metadata(
    source_attributes_node: etree._Element,
    namespace: dict[str, str],
    projection: SARProjection,
    acq_mode: RADARSATAcquisitionModes,
) -> meta.DataSetInfo:
    """Creating a DataSetInfo Arepytools metadata element from xml nodes.

    Parameters
    ----------
    source_attributes_node : etree._Element
        sourceAttributes metadata xml node
    namespace : dict[str, str]
        xml namespace
    projection : SARProjection
        product projection
    acq_mode : RADARSATAcquisitionModes
        acquisition mode

    Returns
    -------
    DataSetInfo
        DataSetInfo metadata object
    """
    sensor_name = source_attributes_node.xpath(".//base:satellite", namespaces=namespace)[0].text
    fc_hz = float(
        source_attributes_node.xpath(".//base:radarParameters/base:radarCenterFrequency", namespaces=namespace)[0].text
    )

    if projection == SARProjection.SLANT_RANGE:
        image_type = "AZIMUTH FOCUSED RANGE COMPENSATED"
    else:
        image_type = "MULTILOOK"

    dataset_info = meta.DataSetInfo(acquisition_mode_i=acq_mode.value, fc_hz_i=fc_hz)
    dataset_info.sensor_name = sensor_name
    dataset_info.image_type = image_type
    dataset_info.projection = projection.value
    dataset_info.side_looking = meta.ESideLooking(
        source_attributes_node.xpath(".//base:radarParameters/base:antennaPointing", namespaces=namespace)[
            0
        ].text.upper()
    )

    return dataset_info


def sampling_constants_from_metadata(
    image_generation_parameters_node: etree._Element,
    namespace: dict[str, str],
    raster_info: meta.RasterInfo,
    projection: SARProjection,
) -> SARSamplingFrequencies:
    """Creating a SARSamplingFrequencies metadata element from xml nodes.

    Parameters
    ----------
    image_generation_parameters_node : etree._Element
        imageGenerationParameters metadata xml node
    namespace : dict[str, str]
        xml namespace
    raster_info : meta.RasterInfo
        raster info
    projection : SARProjection
        product projection

    Returns
    -------
    SARSamplingFrequencies
        sampling frequencies
    """

    if projection == SARProjection.SLANT_RANGE:
        sampling_constants = SARSamplingFrequencies(
            azimuth_freq_hz=1 / raster_info.lines_step,
            azimuth_bandwidth_freq_hz=float(
                image_generation_parameters_node.xpath(
                    ".//base:sarProcessingInformation/base:totalProcessedAzimuthBandwidth", namespaces=namespace
                )[0].text
            ),
            range_freq_hz=1 / raster_info.samples_step,
            range_bandwidth_freq_hz=float(
                image_generation_parameters_node.xpath(
                    ".//base:sarProcessingInformation/base:totalProcessedRangeBandwidth", namespaces=namespace
                )[0].text
            ),
        )
    else:
        sampling_constants = SARSamplingFrequencies(
            azimuth_freq_hz=0,
            azimuth_bandwidth_freq_hz=0,
            range_freq_hz=0,
            range_bandwidth_freq_hz=0,
        )

    return sampling_constants


def orbit_from_state_vectors(state_vectors: RADARSATStateVectors) -> Orbit:
    """Creating an Orbit Arepytools object from RADARSATStateVectors data.

    Parameters
    ----------
    state_vectors : RADARSATStateVectors
        state vectors data

    Returns
    -------
    Orbit
        Orbit object
    """
    return Orbit(times=state_vectors.time_axis, positions=state_vectors.positions, velocities=state_vectors.velocities)


def calibration_factor_from_metadata(file_path: str | Path, product_type: RADARSATProductType) -> float:
    """Retrieving the correct calibration factor to convert digital values to Beta Nought.

    Parameters
    ----------
    file_path : str | Path
        Path to the calibration LUT .xml file

    Returns
    -------
    float
        beta nought calibration factor
    """
    cal_factor = read_lut(path=file_path)
    if product_type == RADARSATProductType.SLC:
        return 1 / cal_factor
    return 1 / np.sqrt(cal_factor)


def doppler_centroid_poly_from_metadata(
    doppler_centroid_node: etree._Element, namespace: dict[str, str]
) -> SortedPolyList:
    """Creating a SortedPolyList Arepytools doppler centroid polynomial wrapper from safe xml node.

    Parameters
    ----------
    doppler_centroid_node : etree._Element
        dopplerCentroid metadata xml node
    namespace : dict[str, str]
        xml namespace

    Returns
    -------
    SortedPolyList
        SortedPolyList wrapper on DopplerCentroidVector metadata object
    """
    azimuth_time_ref = PreciseDateTime.fromisoformat(
        doppler_centroid_node.xpath(".//base:timeOfDopplerCentroidEstimate", namespaces=namespace)[0].text
    )
    range_time_ref = float(
        doppler_centroid_node.xpath(".//base:dopplerCentroidReferenceTime", namespaces=namespace)[0].text
    )
    coeff_raw = [
        float(c)
        for c in doppler_centroid_node.xpath(".//base:dopplerCentroidCoefficients", namespaces=namespace)[
            0
        ].text.split()
    ]
    # up to 5 coefficients can be present, but not always 5
    if len(coeff_raw) < 5:
        for _ in range(5 - len(coeff_raw)):
            coeff_raw.append(0)
    coefficients = [
        coeff_raw[0],
        coeff_raw[1],
        0,  # mixed term
        0,  # mixed term
        coeff_raw[2],
        coeff_raw[3],
        coeff_raw[4],
        0,
    ]

    doppler_centroid = meta.DopplerCentroid(
        i_ref_az=azimuth_time_ref, i_ref_rg=range_time_ref, i_coefficients=coefficients
    )

    return create_sorted_poly_list(poly2d_vector=meta.DopplerCentroidVector([doppler_centroid]))


def doppler_rate_poly_from_metadata(doppler_rate_node: etree._Element, namespace: dict[str, str]) -> SortedPolyList:
    """Creating a SortedPolyList Arepytools doppler rate polynomial wrapper from safe xml node.

    Parameters
    ----------
    doppler_rate_node : etree._Element
        dopplerRateValues metadata xml node
    namespace : dict[str, str]
        xml namespace

    Returns
    -------
    SortedPolyList
        SortedPolyList wrapper on DopplerRateVector metadata object
    """
    azimuth_ref = PreciseDateTime.fromisoformat(
        doppler_rate_node.xpath("..//base:dopplerCentroid/base:timeOfDopplerCentroidEstimate", namespaces=namespace)[
            0
        ].text
    )
    range_time_ref = float(doppler_rate_node.xpath(".//base:dopplerRateReferenceTime", namespaces=namespace)[0].text)
    coeff_raw = [
        float(c)
        for c in doppler_rate_node.xpath(".//base:dopplerRateValuesCoefficients", namespaces=namespace)[0].text.split()
    ]
    # up to 5 coefficients can be present, but not always 5
    if len(coeff_raw) < 5:
        for _ in range(5 - len(coeff_raw)):
            coeff_raw.append(0)
    coefficients = [
        coeff_raw[0],
        coeff_raw[1],
        0,  # mixed term
        0,  # mixed term
        coeff_raw[2],
        coeff_raw[3],
        coeff_raw[4],
        0,
    ]

    doppler_rate = meta.DopplerRate(i_ref_az=azimuth_ref, i_ref_rg=range_time_ref, i_coefficients=coefficients)

    return create_sorted_poly_list(poly2d_vector=meta.DopplerRateVector([doppler_rate]))


@dataclass
class RADARSATStateVectors:
    """RADARSAT-2 orbit's state vectors"""

    num: int
    orbit_direction: OrbitDirection  # orbit direction: ascending or descending
    positions: np.ndarray  # platform position data with respect to the Earth-fixed reference frame
    velocities: np.ndarray  # platform velocity data with respect to the Earth-fixed reference frame
    time_axis: np.ndarray  # PreciseDateTime axis at which orbit state vectors apply
    time_step: float  # time axis step

    @staticmethod
    def _unpack_state_vectors(
        node: etree._Element, namespace: dict[str, str]
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Extracting an array of shape (N, 3) with x, y, z components for positions and velocities of state vectors.
        Recovering also the time axis in PreciseDateTime format.

        Parameters
        ----------
        node : etree._Element
            orbitInformation node from .xml metadata
        namespace : dict[str, str]
            xml namespace

        Returns
        -------
        np.ndarray
            positions, with shape (N, 3)
        ndarray
            velocities, with shape (N, 3)
        ndarray
            time axis, with shape (N,)
        """
        pos_x = np.array(
            [float(x.text) for x in node.xpath(".//base:stateVector/base:xPosition", namespaces=namespace)]
        )
        pos_y = np.array(
            [float(y.text) for y in node.xpath(".//base:stateVector/base:yPosition", namespaces=namespace)]
        )
        pos_z = np.array(
            [float(z.text) for z in node.xpath(".//base:stateVector/base:zPosition", namespaces=namespace)]
        )
        positions = np.stack([pos_x, pos_y, pos_z], axis=1)

        vel_x = np.array(
            [float(x.text) for x in node.xpath(".//base:stateVector/base:xVelocity", namespaces=namespace)]
        )
        vel_y = np.array(
            [float(y.text) for y in node.xpath(".//base:stateVector/base:yVelocity", namespaces=namespace)]
        )
        vel_z = np.array(
            [float(z.text) for z in node.xpath(".//base:stateVector/base:zVelocity", namespaces=namespace)]
        )
        velocities = np.stack([vel_x, vel_y, vel_z], axis=1)

        time_axis = np.array(
            [
                PreciseDateTime.fromisoformat(t.text)
                for t in node.xpath(".//base:stateVector/base:timeStamp", namespaces=namespace)
            ]
        )

        return positions, velocities, time_axis

    @staticmethod
    def from_metadata(orbit_data_node: etree._Element, namespace: dict[str, str]) -> RADARSATStateVectors:
        """Generating a RADARSATStateVectors object directly from metadata xml node.

        Parameters
        ----------
        orbit_data_node : etree._Element
            orbitInformation xml node
        namespace : dict[str, str]
            xml namespace

        Returns
        -------
        RADARSATStateVectors
            orbit's state vectors dataclass
        """
        orbit_direction = OrbitDirection(
            orbit_data_node.xpath(".//base:passDirection", namespaces=namespace)[0].text.lower()
        )
        positions, velocities, times = RADARSATStateVectors._unpack_state_vectors(
            node=orbit_data_node, namespace=namespace
        )
        assert positions.shape[0] == velocities.shape[0] == times.size

        return RADARSATStateVectors(
            num=times.size,
            orbit_direction=orbit_direction,
            positions=positions,
            velocities=velocities,
            time_axis=times,
            time_step=np.mean(np.diff(times)),
        )


@dataclass
class RADARSATBurstInfo:
    """RADARSAT-2 swath burst info"""

    num: int  # number of bursts in this swath
    lines_per_burst: int  # number of azimuth lines within each burst
    samples_per_burst: int  # number of range samples within each burst
    azimuth_start_times: np.ndarray  # zero doppler azimuth time of the first line of this burst
    range_start_times: np.ndarray  # zero doppler range time of the first sample of this burst


@dataclass
class RADARSATSwathInfo:
    """RADARSAT-2 swath info"""

    rank: int
    azimuth_steering_rate_poly: tuple[float, float, float]
    prf: float

    @staticmethod
    def from_metadata(
        source_attributes_node: etree._Element, namespace: dict[str, str], prod_type: RADARSATProductType
    ) -> RADARSATSwathInfo:
        """Generating RADARSATSwathInfo object directly from metadata xml nodes.

        Parameters
        ----------
        source_attributes_node : etree._Element
            sourceAttributes xml node
        namespace : dict[str, str]
            xml namespace
        prod_type : RADARSATProductType
            product type

        Returns
        -------
        RADARSATSwathInfo
            swath info dataclass
        """
        rank = 0
        acquisition_prf = 0
        if prod_type == RADARSATProductType.SLC:
            rank = int(source_attributes_node.xpath(".//base:radarParameters/base:rank", namespaces=namespace)[0].text)
            acquisition_prf = float(
                source_attributes_node.xpath(
                    ".//base:radarParameters/base:pulseRepetitionFrequency", namespaces=namespace
                )[0].text
            )

        return RADARSATSwathInfo(rank=rank, azimuth_steering_rate_poly=(0, 0, 0), prf=acquisition_prf)


@dataclass
class RADARSATAttitude:
    """RADARSAT-2 sensor's attitude"""

    num: int  # attitude data numerosity (same as interpolated orbit)
    yaw_deg: np.ndarray  # platform yaw
    pitch_deg: np.ndarray  # platform pitch
    roll_deg: np.ndarray  # platform roll
    time_axis: np.ndarray  # PreciseDateTime axis to which attitude data applies
    time_step: float  # time axis step

    @staticmethod
    def _unpack_attitude_data(
        node: etree._Element, namespace: dict[str, str]
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Extracting yaw, pitch, roll and times vector from metadata node.

        Parameters
        ----------
        node : etree._Element
            attitudeInformation node from .xml metadata
        namespace : dict[str, str]
            xml namespace

        Returns
        -------
        np.ndarray
            yaw in deg, with shape (N,)
        ndarray
            pitch in deg, with shape (N,)
        ndarray
            roll in deg, with shape (N,)
        ndarray
            time axis, with shape (N,)
        """
        yaw = np.array([float(x.text) for x in node.xpath(".//base:attitudeAngles/base:yaw", namespaces=namespace)])
        pitch = np.array([float(y.text) for y in node.xpath(".//base:attitudeAngles/base:pitch", namespaces=namespace)])
        roll = np.array([float(z.text) for z in node.xpath(".//base:attitudeAngles/base:roll", namespaces=namespace)])
        time_axis = np.array(
            [
                PreciseDateTime.fromisoformat(t.text)
                for t in node.xpath(".//base:attitudeAngles/base:timeStamp", namespaces=namespace)
            ]
        )

        return yaw, pitch, roll, time_axis

    # TODO: this should be a class method (cls, ...)
    @staticmethod
    def from_metadata(attitude_data_node: etree._Element, namespace: dict[str, str]) -> RADARSATAttitude:
        """Generating RADARSATAttitude object directly from metadata xml node.

        Parameters
        ----------
        attitude_data_node : etree._Element
            attitudeInformation xml node
        namespace : dict[str, str]
            xml namespace

        Returns
        -------
        RADARSATAttitude
            sensor's attitude dataclass
        """
        yaw, pitch, roll, times = RADARSATAttitude._unpack_attitude_data(node=attitude_data_node, namespace=namespace)
        assert yaw.size == pitch.size == roll.size == times.size
        return RADARSATAttitude(
            num=times.size,
            yaw_deg=yaw,
            pitch_deg=pitch,
            roll_deg=roll,
            time_axis=times,
            time_step=np.mean(np.diff(times)),
        )


@dataclass
class RADARSATCoordinateConversions:
    """RADARSAT-2 coordinate conversion"""

    ground_to_slant: list[ConversionPolynomial] | None = None
    slant_to_ground: list[ConversionPolynomial] | None = None
    azimuth_reference_times: np.ndarray | None = None

    def _detect_right_polynomial_index(self, azimuth_time: PreciseDateTime) -> int:
        """Detecting the index of the right polynomial to be used given an input azimuth time.
        The polynomial to be used is the one with reference azimuth time closest to the input value but with
        reference_azimuth_time < input_azimuth_time.

        Parameters
        ----------
        azimuth_time : PreciseDateTime
            selected azimuth time

        Returns
        -------
        int
            index corresponding to the polynomial to be used
        """
        diff = np.array(azimuth_time - self.azimuth_reference_times).astype("float")
        return np.ma.masked_where(diff < 0, diff).argmin()

    @staticmethod
    def from_metadata(
        image_generation_parameters_node: etree._Element, namespace: dict[str, str], raster_info: meta.RasterInfo
    ) -> RADARSATCoordinateConversions:
        """Generating RADARSATCoordinateConversions object directly from metadata xml node.

        About coefficients annotated in metadata:

        Coefficients of polynomial fit to the "Ground to Slant Range" transform applied. Fixed along all image slices.
        Defined with respect to (slant range in m)/(pixel no.)^n where first pixel in line is 0.

        Values output in order A0, A1, ...,  An, in order of increasing degree.
        Polynomial to be evaluated is:  A_0+ A_1 x + ... + A_n x^n
        where x is pixel number in the line, starting from 0.

        Evaluated polynomial gives Slant Range in meters.

        Parameters
        ----------
        image_generation_parameters_node : etree._Element
            imageGenerationParameters metadata xml node
        namespace : dict[str, str]
            xml namespace
        raster_info : meta.RasterInfo
            product raster info

        Returns
        -------
        RADARSATCoordinateConversions
            polynomial for coordinate conversion dataclass
        """
        conversion_nodes = image_generation_parameters_node.xpath(
            ".//base:slantRangeToGroundRange", namespaces=namespace
        )
        ground_to_slant_poly_list = []
        slant_to_ground_poly_list = []
        azimuth_times = []
        for node in conversion_nodes:
            azimuth_ref_time = PreciseDateTime.fromisoformat(
                node.xpath(".//base:zeroDopplerAzimuthTime", namespaces=namespace)[0].text
            )
            origin = float(node.xpath(".//base:groundRangeOrigin", namespaces=namespace)[0].text)
            coefficients = [
                float(c) / (LIGHT_SPEED / 2)
                for c in node.xpath(".//base:groundToSlantRangeCoefficients", namespaces=namespace)[0].text.split()
            ]
            ground_to_slant_poly = Polynomial(coef=coefficients)
            ground_to_slant_poly_list.append(
                ConversionPolynomial(
                    azimuth_reference_time=azimuth_ref_time,
                    origin=origin,
                    polynomial=ground_to_slant_poly,
                )
            )
            # slant to ground poly is not given, so it must be evaluated by inverting the ground to slant poly
            rng_axis = np.arange(0, (raster_info.samples + 1) * raster_info.samples_step, raster_info.samples_step) * (
                LIGHT_SPEED / 2
            )
            ground_to_slant_poly_evaluated = ground_to_slant_poly(rng_axis - origin)
            slant_to_ground_poly = Polynomial.fit(
                x=ground_to_slant_poly_evaluated, y=rng_axis, deg=ground_to_slant_poly.degree()
            )
            slant_to_ground_poly_list.append(
                ConversionPolynomial(
                    azimuth_reference_time=azimuth_ref_time,
                    origin=0,
                    polynomial=slant_to_ground_poly,
                )
            )
            azimuth_times.append(azimuth_ref_time)

        return RADARSATCoordinateConversions(
            azimuth_reference_times=np.array(azimuth_times),
            ground_to_slant=ground_to_slant_poly_list,
            slant_to_ground=slant_to_ground_poly_list,
        )

    def evaluate_ground_to_slant(self, azimuth_time: PreciseDateTime, ground_range: ArrayLike) -> float:
        """Compute ground to slant conversion.

        Parameters
        ----------
        azimuth_time : PreciseDateTime
            azimuth time to select the proper polynomial to be used for conversion
        ground_range : ArrayLike
            ground range value(s) in meters

        Returns
        -------
        float
            slant range value
        """
        poly_index = self._detect_right_polynomial_index(azimuth_time=azimuth_time)
        poly = self.ground_to_slant[poly_index]
        return poly.polynomial(ground_range - poly.origin)

    def evaluate_slant_to_ground(self, azimuth_time: PreciseDateTime, slant_range: ArrayLike) -> float:
        """Compute slant to ground conversion.

        Parameters
        ----------
        azimuth_time : PreciseDateTime
            azimuth time to select the proper polynomial to be used for conversion
        slant_range : ArrayLike
            slant range value(s) in meters

        Returns
        -------
        float
            ground range value
        """
        poly_index = self._detect_right_polynomial_index(azimuth_time=azimuth_time)
        poly = self.slant_to_ground[poly_index]
        return poly.polynomial(slant_range - poly.origin)


@dataclass
class RADARSATGeneralChannelInfo:
    """RADARSAT-2 general channel info representation dataclass"""

    product_name: str
    product_id: int
    channel_id: str
    swath: str
    satellite: str
    acq_start_time: PreciseDateTime
    product_type: RADARSATProductType
    acquisition_mode: RADARSATAcquisitionModes
    acquisition_mode_std: StandardSARAcquisitionMode
    polarization: SARPolarization
    projection: SARProjection
    orbit_direction: OrbitDirection

    @staticmethod
    def from_metadata_node(
        root: etree._Element, namespace: dict[str, str], name: str, channel_id: str
    ) -> RADARSATGeneralChannelInfo:
        """Generating S1GeneralChannelInfo object directly from metadata xml nodes.

        Parameters
        ----------
        root : etree._Element
            root metadata xml node
        namespace : dict[str, str]
            xml namespace
        name : str
            product name
        channel_id : str
            current channel ID

        Returns
        -------
        RADARSATGeneralChannelInfo
            general channel info dataclass
        """
        prod_type = RADARSATProductType(
            root.xpath(
                ".//base:imageGenerationParameters/base:generalProcessingInformation/base:productType",
                namespaces=namespace,
            )[0].text.upper()
        )
        mode = get_acquisition_mode_from_product_type(prod_type=prod_type)
        if mode == RADARSATAcquisitionModes.SCANSAR:
            mode_std = StandardSARAcquisitionMode.SCANSAR
        elif mode == RADARSATAcquisitionModes.STRIPMAP:
            mode_std = StandardSARAcquisitionMode.STRIPMAP
        else:
            mode_std = StandardSARAcquisitionMode.SPOTLIGHT
        return RADARSATGeneralChannelInfo(
            product_name=name,
            product_id=root.xpath(".//base:productId", namespaces=namespace)[0].text,
            channel_id=channel_id,
            swath="S1",
            satellite=root.xpath(".//base:sourceAttributes/base:satellite", namespaces=namespace)[0].text,
            acq_start_time=PreciseDateTime.fromisoformat(
                root.xpath(".//base:sourceAttributes/base:rawDataStartTime", namespaces=namespace)[0].text
            ),
            product_type=prod_type,
            acquisition_mode=mode,
            acquisition_mode_std=mode_std,
            projection=get_projection_from_product_type(prod_type=prod_type),
            polarization=SARPolarization[channel_id.split("_")[-1].upper()],
            orbit_direction=OrbitDirection(
                root.xpath(
                    ".//base:sourceAttributes/base:orbitAndAttitude/base:orbitInformation/base:passDirection",
                    namespaces=namespace,
                )[0].text.lower()
            ),
        )


@dataclass
class RADARSATChannelMetadata:
    """RADARSAT-2 channel metadata dataclass"""

    general_info: RADARSATGeneralChannelInfo
    attitude: RADARSATAttitude
    image_calibration_factor: float
    image_radiometric_quantity: SARRadiometricQuantity
    burst_info: RADARSATBurstInfo
    raster_info: meta.RasterInfo
    dataset_info: meta.DataSetInfo
    swath_info: RADARSATSwathInfo
    sampling_constants: SARSamplingFrequencies
    state_vectors: RADARSATStateVectors
    orbit: Orbit
    samples_ordering: RADARSATTimeOrdering
    lines_ordering: RADARSATTimeOrdering
    doppler_centroid_poly: SortedPolyList
    doppler_rate_poly: SortedPolyList
    coordinate_conversions: RADARSATCoordinateConversions
    pulse: meta.Pulse | None = None
    acquisition_timeline: meta.AcquisitionTimeLine | None = None


def get_basic_info_from_metadata(
    metadata_path: str | Path,
) -> tuple[PreciseDateTime, RADARSATProductType, list[str], tuple[float, float, float, float]]:
    """Recovering acquisition time and list of channels.

    Parameters
    ----------
    metadata_path : str | Path
        Path to RADARSAT-2 metadata file

    Returns
    -------
    PreciseDateTime
        acquisition time in PreciseDateTime format
    RADARSATProductType
        product type
    list[str]
        list of channels ids
    tuple[float, float, float, float]
        scene footprint [min lat, max lat, min lon, max lon]
    """
    metadata_path = Path(metadata_path)
    mtd = metadata_path.read_text(encoding="UTF-8")

    # regex init
    acq_time_re = re.compile("(?<=<rawDataStartTime>).*(?=</rawDataStartTime>)")
    type_re = re.compile("(?<=<productType>).*(?=</productType>)")
    pols_re = re.compile("(?<=<polarizations>).*(?=</polarizations>)")
    footprint_lat_re = re.compile('(?<=<latitude units="deg">).*(?=</latitude>)')
    footprint_lon_re = re.compile('(?<=<longitude units="deg">).*(?=</longitude>)')

    # info extraction
    acq_time = acq_time_re.findall(mtd)[0]
    acq_type = type_re.findall(mtd)[0].lower()
    acq_pols = pols_re.findall(mtd)[0].lower()

    # generating channels names
    pol_list = acq_pols.split()
    channels_list = [acq_type + "_" + pol for pol in pol_list]

    # recovering scene footprint
    footprint_lat = [float(f) for f in footprint_lat_re.findall(mtd)]
    footprint_lon = [float(f) for f in footprint_lon_re.findall(mtd)]
    footprint = (min(footprint_lat), max(footprint_lat), min(footprint_lon), max(footprint_lon))

    return PreciseDateTime.fromisoformat(acq_time), RADARSATProductType(acq_type.upper()), channels_list, footprint


def get_acquisition_mode_from_product_type(prod_type: RADARSATProductType) -> RADARSATAcquisitionModes:
    """Get product acquisition mode from product type.

    Parameters
    ----------
    prod_type : RADARSATProductType
        product type

    Returns
    -------
    RADARSATAcquisitionModes
        product acquisition mode
    """
    # FIXME: spotlight case needed!
    # TODO: check when this is SPOTLIGHT
    if prod_type == RADARSATProductType.SLC:
        return RADARSATAcquisitionModes.STRIPMAP

    return RADARSATAcquisitionModes.SCANSAR


def get_projection_from_product_type(prod_type: RADARSATProductType) -> SARProjection:
    """Get product projection from product type.

    Parameters
    ----------
    prod_type : RADARSATProductType
        product type

    Returns
    -------
    SARProjection
        product projection
    """
    if prod_type is RADARSATProductType.SLC:
        return SARProjection.SLANT_RANGE

    return SARProjection.GROUND_RANGE


class RADARSATProduct:
    """RADARSAT-2 product object"""

    def __init__(self, path: str | Path) -> None:
        """RADARSAT-2 Product init from directory path.

        Parameters
        ----------
        path : str | Path
            path to RADARSAT-2 product
        """
        self._product_path = Path(path)
        self._product_name = self._product_path.name
        self._metadata_path = self._product_path.joinpath(_METADATA_FILE)
        self._acq_time, self._product_type, self._channel_list_by_swath_id, self._footprint = (
            get_basic_info_from_metadata(metadata_path=self._metadata_path)
        )
        self._channels_number = len(self._channel_list_by_swath_id)
        self._data_paths = [
            f
            for f in self._product_path.iterdir()
            if f.name.startswith(_DATA_SUFFIX) and f.name.endswith(_IMAGE_FORMAT)
        ]
        self._beta_calibration_file = self._product_path.joinpath(_LUT_BETA_FILE)

    @property
    def acquisition_time(self) -> PreciseDateTime:
        """Acquisition start time for this product"""
        return self._acq_time

    @property
    def channels_number(self) -> int:
        """Returning the number of channels of COSMO product"""
        return self._channels_number

    @property
    def channels_list(self) -> list[str]:
        """Returning the list of channels in terms of SwathID (swath-polarization)"""
        return self._channel_list_by_swath_id

    @property
    def data_list(self) -> list[Path]:
        """Returning the list of raster data files of RADARSAT-2 product"""
        return self._data_paths

    @property
    def product_type(self) -> RADARSATProductType:
        """Returning the product type"""
        return self._product_type

    @property
    def metadata_file(self) -> Path:
        """Returning the product metadata file path of RADARSAT-2 product"""
        return self._metadata_path

    @property
    def beta_calibration_lut_file(self) -> Path:
        """Returning the beta LUT calibration file path"""
        return self._beta_calibration_file

    @property
    def footprint(self) -> tuple[float, float, float, float]:
        """Product footprint as tuple of (min lat, max lat, min lon, max lon)"""
        return self._footprint

    def get_raster_file_from_channel_name(self, channel_name: str) -> Path:
        """Get raster file path associated to input channel name.

        Parameters
        ----------
        channel_name : str
            selected channel name

        Returns
        -------
        Path
            raster file path
        """
        return [r for r in self.data_list if channel_name.split("_")[-1] in r.name.lower()][0]


def is_radarsat_product(product: str | Path) -> bool:
    """Check if input path corresponds to a valid RADARSAT-2 product, basic version.

    Conditions to be met for basic validity:
        - path is dir
        - metadata file exist
        - read basic info from metadata file

    Parameters
    ----------
    product : str | Path
        path to the product to be checked

    Returns
    -------
    bool
        True if it is a valid product, else False
    """
    product = Path(product)

    if not product.is_dir():
        return False

    if not product.joinpath(_METADATA_FILE).exists():
        return False

    # read basic info from metadata file
    try:
        get_basic_info_from_metadata(metadata_path=product.joinpath(_METADATA_FILE))
    except Exception:
        return False

    return True
