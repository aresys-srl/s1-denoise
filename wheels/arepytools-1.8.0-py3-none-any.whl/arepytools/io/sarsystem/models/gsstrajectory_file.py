# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class AttitudeInfoTypeAttitudeType(Enum):
    NOMINAL = "NOMINAL"
    REFINED = "REFINED"


class AttitudeInfoTypeReferenceFrame(Enum):
    ZERODOPPLER = "ZERODOPPLER"
    GEODETIC = "GEODETIC"
    GEOCENTRIC = "GEOCENTRIC"


class AttitudeInfoTypeRotationOrder(Enum):
    YPR = "YPR"
    YRP = "YRP"
    PYR = "PYR"
    PRY = "PRY"
    RYP = "RYP"
    RPY = "RPY"


class StateVectorDataTypeOrbitDirection(Enum):
    ASCENDING = "ASCENDING"
    DESCENDING = "DESCENDING"


@dataclass
class ValueArrayType:
    val: list["ValueArrayType.Val"] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "min_occurs": 1,
        },
    )

    @dataclass
    class Val:
        value: Optional[float] = field(
            default=None,
            metadata={
                "required": True,
            },
        )
        n: Optional[object] = field(
            default=None,
            metadata={
                "name": "N",
                "type": "Attribute",
                "required": True,
            },
        )


@dataclass
class AttitudeInfoType:
    t_ref_utc: Optional[str] = field(
        default=None,
        metadata={
            "name": "t_ref_Utc",
            "type": "Element",
            "required": True,
        },
    )
    dt_ypr_s: Optional[float] = field(
        default=None,
        metadata={
            "name": "dtYPR_s",
            "type": "Element",
            "required": True,
        },
    )
    n_ypr_n: Optional[int] = field(
        default=None,
        metadata={
            "name": "nYPR_n",
            "type": "Element",
            "required": True,
        },
    )
    yaw_deg: Optional[ValueArrayType] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    pitch_deg: Optional[ValueArrayType] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    roll_deg: Optional[ValueArrayType] = field(
        default=None,
        metadata={
            "type": "Element",
            "required": True,
        },
    )
    reference_frame: Optional[AttitudeInfoTypeReferenceFrame] = field(
        default=None,
        metadata={
            "name": "referenceFrame",
            "type": "Element",
            "required": True,
        },
    )
    rotation_order: Optional[AttitudeInfoTypeRotationOrder] = field(
        default=None,
        metadata={
            "name": "rotationOrder",
            "type": "Element",
            "required": True,
        },
    )
    attitude_type: Optional[AttitudeInfoTypeAttitudeType] = field(
        default=None,
        metadata={
            "name": "AttitudeType",
            "type": "Element",
            "required": True,
        },
    )


@dataclass
class StateVectorDataType:
    orbit_number: Optional[str] = field(
        default=None,
        metadata={
            "name": "OrbitNumber",
            "type": "Element",
            "required": True,
        },
    )
    track: Optional[str] = field(
        default=None,
        metadata={
            "name": "Track",
            "type": "Element",
            "required": True,
        },
    )
    orbit_direction: Optional[StateVectorDataTypeOrbitDirection] = field(
        default=None,
        metadata={
            "name": "OrbitDirection",
            "type": "Element",
            "required": True,
        },
    )
    p_sv_m: Optional[ValueArrayType] = field(
        default=None,
        metadata={
            "name": "pSV_m",
            "type": "Element",
            "required": True,
        },
    )
    v_sv_m_os: Optional[ValueArrayType] = field(
        default=None,
        metadata={
            "name": "vSV_mOs",
            "type": "Element",
            "required": True,
        },
    )
    t_ref_utc: Optional[str] = field(
        default=None,
        metadata={
            "name": "t_ref_Utc",
            "type": "Element",
            "required": True,
        },
    )
    dt_sv_s: Optional[float] = field(
        default=None,
        metadata={
            "name": "dtSV_s",
            "type": "Element",
            "required": True,
        },
    )
    n_sv_n: Optional[int] = field(
        default=None,
        metadata={
            "name": "nSV_n",
            "type": "Element",
            "required": True,
        },
    )
    ascending_node_time: Optional[str] = field(
        default=None,
        metadata={
            "name": "AscendingNodeTime",
            "type": "Element",
            "required": True,
        },
    )
    ascending_node_coords: Optional[ValueArrayType] = field(
        default=None,
        metadata={
            "name": "AscendingNodeCoords",
            "type": "Element",
            "required": True,
        },
    )


@dataclass
class ChannelType:
    description: Optional[str] = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "required": True,
        },
    )
    full_orbit_cycle_length: Optional["ChannelType.FullOrbitCycleLength"] = field(
        default=None,
        metadata={
            "name": "fullOrbitCycleLength",
            "type": "Element",
            "required": True,
        },
    )
    state_vector_data: Optional[StateVectorDataType] = field(
        default=None,
        metadata={
            "name": "StateVectorData",
            "type": "Element",
            "required": True,
        },
    )
    attitude_info: Optional[AttitudeInfoType] = field(
        default=None,
        metadata={
            "name": "AttitudeInfo",
            "type": "Element",
            "required": True,
        },
    )
    antenna_phase_centre_position_towards_body_mass_center: Optional[
        "ChannelType.AntennaPhaseCentrePositionTowardsBodyMassCenter"
    ] = field(
        default=None,
        metadata={
            "name": "AntennaPhaseCentrePositionTowardsBodyMassCenter",
            "type": "Element",
            "required": True,
        },
    )
    antenna_rotation_ypr: Optional["ChannelType.AntennaRotationYpr"] = field(
        default=None,
        metadata={
            "name": "AntennaRotationYPR",
            "type": "Element",
            "required": True,
        },
    )
    number: Optional[object] = field(
        default=None,
        metadata={
            "name": "Number",
            "type": "Attribute",
            "required": True,
        },
    )
    total: Optional[object] = field(
        default=None,
        metadata={
            "name": "Total",
            "type": "Attribute",
            "required": True,
        },
    )

    @dataclass
    class FullOrbitCycleLength:
        value: Optional[float] = field(
            default=None,
            metadata={
                "required": True,
            },
        )
        unit: str = field(
            init=False,
            default="s",
            metadata={
                "type": "Attribute",
                "required": True,
            },
        )

    @dataclass
    class AntennaPhaseCentrePositionTowardsBodyMassCenter:
        tx: Optional[ValueArrayType] = field(
            default=None,
            metadata={
                "name": "TX",
                "type": "Element",
                "required": True,
            },
        )
        rx: Optional[ValueArrayType] = field(
            default=None,
            metadata={
                "name": "RX",
                "type": "Element",
                "required": True,
            },
        )
        unit: str = field(
            init=False,
            default="m",
            metadata={
                "type": "Attribute",
                "required": True,
            },
        )

    @dataclass
    class AntennaRotationYpr:
        tx: Optional[ValueArrayType] = field(
            default=None,
            metadata={
                "name": "TX",
                "type": "Element",
                "required": True,
            },
        )
        rx: Optional[ValueArrayType] = field(
            default=None,
            metadata={
                "name": "RX",
                "type": "Element",
                "required": True,
            },
        )
        unit: str = field(
            init=False,
            default="deg",
            metadata={
                "type": "Attribute",
                "required": True,
            },
        )


@dataclass
class GsstrajectoryFile:
    class Meta:
        name = "GSSTrajectoryFile"

    version_number: Optional[str] = field(
        default=None,
        metadata={
            "name": "VersionNumber",
            "type": "Element",
            "required": True,
        },
    )
    channel: Optional[ChannelType] = field(
        default=None,
        metadata={
            "name": "Channel",
            "type": "Element",
            "required": True,
        },
    )
