# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ParameterPeriodType:
    relative_time_start: Optional[float] = field(
        default=None,
        metadata={
            "name": "RelativeTimeStart",
            "type": "Element",
            "required": True,
        },
    )
    relative_time_stop: Optional[float] = field(
        default=None,
        metadata={
            "name": "RelativeTimeStop",
            "type": "Element",
            "required": True,
        },
    )
    prf: Optional[float] = field(
        default=None,
        metadata={
            "name": "PRF",
            "type": "Element",
            "required": True,
        },
    )
    swst: Optional[float] = field(
        default=None,
        metadata={
            "name": "SWST",
            "type": "Element",
            "required": True,
        },
    )
    swl: Optional[float] = field(
        default=None,
        metadata={
            "name": "SWL",
            "type": "Element",
            "required": True,
        },
    )
    rank: Optional[int] = field(
        default=None,
        metadata={
            "name": "RANK",
            "type": "Element",
            "required": True,
        },
    )
    noise_figure: Optional[float] = field(
        default=None,
        metadata={
            "name": "NoiseFigure",
            "type": "Element",
            "required": True,
        },
    )
    reference_temperature: Optional[float] = field(
        default=None,
        metadata={
            "name": "ReferenceTemperature",
            "type": "Element",
            "required": True,
        },
    )
    radar_carrier_frequency: Optional[float] = field(
        default=None,
        metadata={
            "name": "RadarCarrierFrequency",
            "type": "Element",
            "required": True,
        },
    )
    transmitted_power: Optional[float] = field(
        default=None,
        metadata={
            "name": "TransmittedPower",
            "type": "Element",
            "required": True,
        },
    )
    period_number: Optional[int] = field(
        default=None,
        metadata={
            "name": "PeriodNumber",
            "type": "Attribute",
            "required": True,
        },
    )


@dataclass
class BeamType:
    sampling_frequency: Optional[float] = field(
        default=None,
        metadata={
            "name": "SamplingFrequency",
            "type": "Element",
            "required": True,
        },
    )
    parameter_period: list[ParameterPeriodType] = field(
        default_factory=list,
        metadata={
            "name": "ParameterPeriod",
            "type": "Element",
            "min_occurs": 1,
        },
    )
    beam_id: Optional[str] = field(
        default=None,
        metadata={
            "name": "BeamID",
            "type": "Attribute",
            "required": True,
        },
    )


@dataclass
class ConfigurationFileDoc:
    version: Optional[str] = field(
        default=None,
        metadata={
            "name": "Version",
            "type": "Element",
            "required": True,
        },
    )
    beam: Optional[BeamType] = field(
        default=None,
        metadata={
            "name": "Beam",
            "type": "Element",
            "required": True,
        },
    )
