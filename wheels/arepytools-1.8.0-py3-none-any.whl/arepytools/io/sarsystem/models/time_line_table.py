# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class EchoTypeType(Enum):
    ECHO = "Echo"
    WARM_UP = "WarmUp"
    NOISE = "Noise"
    INIT_CAL = "InitCal"
    INIT_CAL_TX_CAL = "InitCal_TxCal"
    INIT_CAL_RX_CAL = "InitCal_RxCal"
    INIT_CAL_EPDNCAL = "InitCal_EPDNCal"
    INIT_CAL_TACAL = "InitCal_TACal"
    INIT_CAL_APDNCAL = "InitCal_APDNCal"
    INIT_CAL_TX_CAL100 = "InitCal_TxCal100"
    INIT_CAL_RX_CAL100 = "InitCal_RxCal100"
    INIT_CAL_EPDNCAL100 = "InitCal_EPDNCal100"
    INIT_CAL_TACAL100 = "InitCal_TACal100"
    INIT_CAL_APDNCAL100 = "InitCal_APDNCal100"
    INIT_CAL_RFC_TX_CAL = "InitCal_RFC_TxCal"
    INIT_CAL_RFC_RX_CAL = "InitCal_RFC_RxCal"
    INIT_CAL_RFC_EPDNCAL = "InitCal_RFC_EPDNCal"
    INIT_CAL_RFC_TACAL = "InitCal_RFC_TACal"
    INIT_CAL_RFC_APDNCAL = "InitCal_RFC_APDNCal"
    INIT_CAL_TX_CAL_ISO = "InitCal_TxCalIso"
    INIT_CAL_RX_CAL_ISO = "InitCal_RxCalIso"
    INIT_CAL_EPDNCAL_ISO = "InitCal_EPDNCalIso"
    INIT_CAL_TACAL_ISO = "InitCal_TACalIso"
    INIT_CAL_APDNCAL_ISO = "InitCal_APDNCalIso"
    INIT_CAL_TX_CAL100_ISO = "InitCal_TxCal100Iso"
    INIT_CAL_RX_CAL100_ISO = "InitCal_RxCal100Iso"
    INIT_CAL_EPDNCAL100_ISO = "InitCal_EPDNCal100Iso"
    INIT_CAL_TACAL100_ISO = "InitCal_TACal100Iso"
    INIT_CAL_APDNCAL100_ISO = "InitCal_APDNCal100Iso"
    INIT_CAL_RFC_TX_CAL_ISO = "InitCal_RFC_TxCalIso"
    INIT_CAL_RFC_RX_CAL_ISO = "InitCal_RFC_RxCalIso"
    INIT_CAL_RFC_EPDNCAL_ISO = "InitCal_RFC_EPDNCalIso"
    INIT_CAL_RFC_TACAL_ISO = "InitCal_RFC_TACalIso"
    INIT_CAL_RFC_APDNCAL_ISO = "InitCal_RFC_APDNCalIso"
    CAL = "Cal"
    CAL_TX_CAL = "Cal_TxCal"
    CAL_RX_CAL = "Cal_RxCal"
    CAL_EPDNCAL = "Cal_EPDNCal"
    CAL_TACAL = "Cal_TACal"
    CAL_APDNCAL = "Cal_APDNCal"
    CAL_TX_CAL100 = "Cal_TxCal100"
    CAL_RX_CAL100 = "Cal_RxCal100"
    CAL_EPDNCAL100 = "Cal_EPDNCal100"
    CAL_TACAL100 = "Cal_TACal100"
    CAL_APDNCAL100 = "Cal_APDNCal100"
    CAL_RFC_TX_CAL = "Cal_RFC_TxCal"
    CAL_RFC_RX_CAL = "Cal_RFC_RxCal"
    CAL_RFC_EPDNCAL = "Cal_RFC_EPDNCal"
    CAL_RFC_TACAL = "Cal_RFC_TACal"
    CAL_RFC_APDNCAL = "Cal_RFC_APDNCal"
    CAL_TX_CAL_ISO = "Cal_TxCalIso"
    CAL_RX_CAL_ISO = "Cal_RxCalIso"
    CAL_EPDNCAL_ISO = "Cal_EPDNCalIso"
    CAL_TACAL_ISO = "Cal_TACalIso"
    CAL_APDNCAL_ISO = "Cal_APDNCalIso"
    CAL_TX_CAL100_ISO = "Cal_TxCal100Iso"
    CAL_RX_CAL100_ISO = "Cal_RxCal100Iso"
    CAL_EPDNCAL100_ISO = "Cal_EPDNCal100Iso"
    CAL_TACAL100_ISO = "Cal_TACal100Iso"
    CAL_APDNCAL100_ISO = "Cal_APDNCal100Iso"
    CAL_RFC_TX_CAL_ISO = "Cal_RFC_TxCalIso"
    CAL_RFC_RX_CAL_ISO = "Cal_RFC_RxCalIso"
    CAL_RFC_EPDNCAL_ISO = "Cal_RFC_EPDNCalIso"
    CAL_RFC_TACAL_ISO = "Cal_RFC_TACalIso"
    CAL_RFC_APDNCAL_ISO = "Cal_RFC_APDNCalIso"
    TXCAL512 = "TXCal512"
    RXCAL512 = "RXCal512"
    TXCAL_RFC = "TXCalRFC"
    RXCAL_RFC = "RXCalRFC"
    EPCAL32 = "EPCal32"
    TACAL32 = "TACal32"
    APCAL1 = "APCal1"
    SILENT = "silent"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"
    P4 = "P4"
    P5 = "P5"


@dataclass
class IndexType:
    val: list["IndexType.Val"] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "min_occurs": 1,
        },
    )

    @dataclass
    class Val:
        value: Optional[int] = field(
            default=None,
            metadata={
                "required": True,
            },
        )
        n: Optional[int] = field(
            default=None,
            metadata={
                "name": "N",
                "type": "Attribute",
                "required": True,
            },
        )


@dataclass
class PatternListType:
    pattern: list["PatternListType.Pattern"] = field(
        default_factory=list,
        metadata={
            "name": "Pattern",
            "type": "Element",
            "min_occurs": 1,
        },
    )

    @dataclass
    class Pattern:
        pattern_index: Optional[int] = field(
            default=None,
            metadata={
                "name": "PatternIndex",
                "type": "Element",
                "required": True,
            },
        )
        time_validity: Optional["PatternListType.Pattern.TimeValidity"] = field(
            default=None,
            metadata={
                "name": "TimeValidity",
                "type": "Element",
            },
        )
        n: Optional[int] = field(
            default=None,
            metadata={
                "name": "N",
                "type": "Attribute",
                "required": True,
            },
        )

        @dataclass
        class TimeValidity:
            start: Optional[float] = field(
                default=None,
                metadata={
                    "name": "Start",
                    "type": "Element",
                    "required": True,
                },
            )
            stop: Optional[float] = field(
                default=None,
                metadata={
                    "name": "Stop",
                    "type": "Element",
                    "required": True,
                },
            )
            unit: Optional[str] = field(
                default=None,
                metadata={
                    "name": "Unit",
                    "type": "Attribute",
                    "required": True,
                },
            )


@dataclass
class SteeringVelocityType:
    val: list["SteeringVelocityType.Val"] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "min_occurs": 1,
        },
    )
    unit: str = field(
        init=False,
        default="rad/s",
        metadata={
            "type": "Attribute",
            "required": True,
        },
    )

    @dataclass
    class Val:
        value: Optional[float] = field(
            default=None,
            metadata={
                "required": True,
            },
        )
        beam_id: Optional[object] = field(
            default=None,
            metadata={
                "name": "BeamID",
                "type": "Attribute",
                "required": True,
            },
        )


@dataclass
class TimeLinePeriodType:
    beam_id: Optional[str] = field(
        default=None,
        metadata={
            "name": "BeamID",
            "type": "Element",
            "required": True,
        },
    )
    echo_type: Optional[EchoTypeType] = field(
        default=None,
        metadata={
            "name": "EchoType",
            "type": "Element",
            "required": True,
        },
    )
    number_of_echoes: Optional[int] = field(
        default=None,
        metadata={
            "name": "NumberOfEchoes",
            "type": "Element",
            "required": True,
        },
    )
    pattern_list_tx: Optional[PatternListType] = field(
        default=None,
        metadata={
            "name": "PatternListTX",
            "type": "Element",
        },
    )
    pattern_list_rx: Optional[PatternListType] = field(
        default=None,
        metadata={
            "name": "PatternListRX",
            "type": "Element",
        },
    )
    azimuth_steering_index_tx: Optional[IndexType] = field(
        default=None,
        metadata={
            "name": "AzimuthSteeringIndexTX",
            "type": "Element",
            "required": True,
        },
    )
    azimuth_steering_index_rx: Optional[IndexType] = field(
        default=None,
        metadata={
            "name": "AzimuthSteeringIndexRX",
            "type": "Element",
            "required": True,
        },
    )
    chirp_index: Optional[IndexType] = field(
        default=None,
        metadata={
            "name": "ChirpIndex",
            "type": "Element",
            "required": True,
        },
    )
    period_number: Optional[int] = field(
        default=None,
        metadata={
            "name": "PeriodNumber",
            "type": "Attribute",
            "required": True,
        },
    )


@dataclass
class CycleType:
    timeline_period: list[TimeLinePeriodType] = field(
        default_factory=list,
        metadata={
            "name": "TimelinePeriod",
            "type": "Element",
            "min_occurs": 1,
        },
    )


@dataclass
class ModeType:
    steering_velocity: Optional[SteeringVelocityType] = field(
        default=None,
        metadata={
            "name": "SteeringVelocity",
            "type": "Element",
            "required": True,
        },
    )
    initial_cycle: Optional[CycleType] = field(
        default=None,
        metadata={
            "name": "InitialCycle",
            "type": "Element",
        },
    )
    acquisition_cycle: Optional[CycleType] = field(
        default=None,
        metadata={
            "name": "AcquisitionCycle",
            "type": "Element",
            "required": True,
        },
    )
    end_cycle: Optional[CycleType] = field(
        default=None,
        metadata={
            "name": "EndCycle",
            "type": "Element",
        },
    )
    mode_id: Optional[object] = field(
        default=None,
        metadata={
            "name": "ModeID",
            "type": "Attribute",
            "required": True,
        },
    )


@dataclass
class Sensor:
    version: Optional[str] = field(
        default=None,
        metadata={
            "name": "Version",
            "type": "Element",
            "required": True,
        },
    )
    mode: Optional[ModeType] = field(
        default=None,
        metadata={
            "name": "Mode",
            "type": "Element",
            "required": True,
        },
    )
