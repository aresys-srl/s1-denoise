# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
read sat tables (timeline table, swathtable) module
---------------------------------------------------
"""

from pathlib import Path

from arepytools.io.sarsystem.sat_table import BeamNumberEachPeriod, SatTable, TimeLine
from arepytools.io.sarsystem.swathtable_read import read_swath_table
from arepytools.io.sarsystem.timeline_table_read import read_timeline_table


def timeline_to_beamnumbereachperiod(timeline_table: TimeLine) -> BeamNumberEachPeriod:
    """
    Extracts beam acquisition cycle data from the given `TimelineTable` instance.
    """

    acquisition_cycle = timeline_table.acquisition_cycle
    initial_cycle = timeline_table.initial_cycle
    end_cycle = timeline_table.end_cycle

    # create class object beam_each_number_period
    beam_number_each_period = BeamNumberEachPeriod(
        acquisition_cycle=acquisition_cycle,
        initial_cycle=initial_cycle,
        end_cycle=end_cycle,
    )

    return beam_number_each_period


def read_sat_table(
    SARSystem_folder_name: str | Path,
    acq_mode_ID: str,
) -> SatTable:
    """
    Reads satellite acquisition data and returns a `SatTable` instance containing various related information.

    Parameters
    ----------
    SARSystem_folder_name : Path | str
        The path to the root directory containing the SAR system data, including acquisition modes and swaths.

    acq_mode_ID : str
        The acquisition mode identifier, which is used to locate the corresponding `TimelineTable.xml` and
        determine the beam information.

    Returns
    -------
    SatTable
        An instance of the `SatTable` class that contains the following fields:
        - timeline_table : `TimeLineTable`
            An instance of the `TimeLineTable` class.
        - swath_table : dict
            A dictionary mapping each beam name to its corresponding `SwathTable` instance.
        - beam_number_each_period : `BeamNumberEachPeriod`
            An instance containing different acquisition cycles, including `initial_cycle` and `end_cycle` fields.
        - beam_name2number : list of `SteeringVelocity`
            A list of `SteeringVelocity` instances, where each contains a beam name and its respective
              steering velocity.
    """
    SARSystem_folder_name = Path(SARSystem_folder_name)
    timeline_filename = SARSystem_folder_name / "AcquisitionModes" / acq_mode_ID / "TimelineTable.xml"
    timeline_table = read_timeline_table(timeline_filename)

    beam_name2number = timeline_table.steering_velocity_list

    # Each beam has its own XML file and a swathtable list that contains each kind of beam (SwathTable istance)
    #  is created
    swath_table = {}
    for beam in beam_name2number:
        beam_name = beam.beam_id

        swath_filename = SARSystem_folder_name / "Swaths" / beam_name / "SwathParameterTable.xml"
        swath_table[beam_name] = read_swath_table(swath_filename)

    beam_number_each_period = timeline_to_beamnumbereachperiod(timeline_table)

    return SatTable(
        timeline_table=timeline_table,
        beam_number_each_period=beam_number_each_period,
        swath_table=swath_table,
        beam_name2number=beam_name2number,
    )
