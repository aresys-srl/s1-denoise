# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
write swathtable module
-----------------------
"""

from pathlib import Path

from xsdata.formats.dataclass.serializers import XmlSerializer
from xsdata.formats.dataclass.serializers.config import SerializerConfig

from arepytools.io.sarsystem.models import swath_parameter_table as swathtable_model
from arepytools.io.sarsystem.swathtable import SwathTable


def swathtable_to_model(swathtable: SwathTable, version_number: str = "2.0") -> swathtable_model.ConfigurationFileDoc:
    """
    Convert a SwathTable object into a ConfigurationFileDoc model.

    This function transforms a `SwathTable` data structure into a
    `ConfigurationFileDoc` object compatible with the `swathtable_model` format,
    optionally setting a specific version number.
    """

    if not isinstance(swathtable, SwathTable):
        raise TypeError("swathtable  is not a SwathTable object")

    parameter_period = [
        swathtable_model.ParameterPeriodType(
            relative_time_start=param.start_time,
            relative_time_stop=param.stop_time,
            prf=param.prf,
            swst=param.swst,
            swl=param.swl,
            rank=param.rank,
            noise_figure=param.noise_figure,
            reference_temperature=param.temperature_ref,
            radar_carrier_frequency=param.f_c,
            transmitted_power=param.p_tx,
            period_number=i + 1,  # Assuming period number starts from 1
        )
        for i, param in enumerate(swathtable.parameter_period)
    ]

    beam = swathtable_model.BeamType(
        sampling_frequency=swathtable.freq_sampling, parameter_period=parameter_period, beam_id=swathtable.beam_id
    )

    return swathtable_model.ConfigurationFileDoc(version=version_number, beam=beam)


def write_swath_table_xml(swathtable: SwathTable, xml_dir_path: str | Path):
    """
    Serialize the swathtable model to XML and write to file.

    Parameters
    ----------
    swathtable: SwathTable
        swathtable object to serialize.
    xml_path : Path
        Destination file path for the output XML.
    """
    swathtable_model = swathtable_to_model(swathtable=swathtable)
    config = SerializerConfig(pretty_print=True, encoding="utf-8", indent="       ")
    serializer = XmlSerializer(config=config)
    xml_dir_path = Path(xml_dir_path)
    xml_path = xml_dir_path.joinpath("SwathParameterTable.xml")
    xml_path.parent.mkdir(parents=True, exist_ok=True)
    with open(xml_path, "w") as file:
        serializer.write(file, swathtable_model)
