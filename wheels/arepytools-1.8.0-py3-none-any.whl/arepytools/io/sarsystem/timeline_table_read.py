# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
read timeline table module
--------------------------
"""

from pathlib import Path

from xsdata.formats.dataclass.parsers import XmlParser

from arepytools.io.sarsystem.models import time_line_table as model_timeline
from arepytools.io.sarsystem.timeline_table import TimeLine


def read_timeline_table(filename: Path) -> TimeLine:
    xml_parser = XmlParser()
    file_content = xml_parser.parse(filename, model_timeline.Sensor)
    return TimeLine.from_model(file_content)
