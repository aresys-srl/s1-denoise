# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
read trajectory module
----------------------
"""

from pathlib import Path

from xsdata.formats.dataclass.parsers import XmlParser

from arepytools.io.sarsystem.models import gsstrajectory_file as model_trajectory
from arepytools.io.sarsystem.trajectory import (
    AntennaPhaseCentrePositionTowardsBodyMassCenter,
    AntennaRotation,
    AttitudeInfo,
    GssTrajectory,
    StateVectorData,
)
from arepytools.io.sarsystem.utils import (
    value_array_type_to_array,
)


def read_trajectory(filename: Path) -> GssTrajectory:
    """
    Read a GSS trajectory XML file and parse its contents into a GssTrajectory object.

    Parameters
    ----------
    filename : Path
        Path to the XML file containing the trajectory data.

    Returns
    -------
    GssTrajectory
        Parsed trajectory data as a GssTrajectory object.
    """
    xml_parser = XmlParser()
    file_content = xml_parser.parse(filename, model_trajectory.GsstrajectoryFile)

    # antenna_phase_centre_position_towards_body_mass_center
    antenna_phase_centre_position_towards_body_mass_center = AntennaPhaseCentrePositionTowardsBodyMassCenter(
        tx=value_array_type_to_array(
            file_content.channel.antenna_phase_centre_position_towards_body_mass_center.tx
        ).reshape([-1, 3]),
        rx=value_array_type_to_array(
            file_content.channel.antenna_phase_centre_position_towards_body_mass_center.rx
        ).reshape([-1, 3]),
    )

    # Antenna Rotation
    antenna_rotation = AntennaRotation.from_model(file_content.channel.antenna_rotation_ypr)

    # state vector
    state_vector = StateVectorData.from_model(file_content.channel.state_vector_data)

    # attitude info
    attitude_info = AttitudeInfo.from_model(file_content.channel.attitude_info)

    return GssTrajectory(
        orbit_length=file_content.channel.full_orbit_cycle_length.value,
        attitude_info=attitude_info,
        state_vector=state_vector,
        antenna_rotation=antenna_rotation,
        antenna_phase_centre_position_towards_body_mass_center=antenna_phase_centre_position_towards_body_mass_center,
    )
